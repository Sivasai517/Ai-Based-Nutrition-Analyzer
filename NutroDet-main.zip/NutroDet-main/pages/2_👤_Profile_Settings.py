import streamlit as st
from utils import load_medical_conditions, calculate_bmr

st.title('👤 Profile Settings')
st.write('Configure your personal health profile for personalized recommendations.')

# User profile settings
age = st.number_input('Age', min_value=1, max_value=120, value=st.session_state.get('age', 30))
gender = st.selectbox('Gender', ['Female', 'Male'], index=0 if st.session_state.get('gender', 'Female') == 'Female' else 1)
weight = st.number_input('Weight (kg)', min_value=20, max_value=200, value=st.session_state.get('weight', 60))
height = st.number_input('Height (cm)', min_value=100, max_value=250, value=st.session_state.get('height', 165))

# Activity level
activity_level = st.select_slider('Activity Level',
    options=['Sedentary', 'Light', 'Moderate', 'Active', 'Very Active'],
    value=st.session_state.get('activity_level', 'Light'))

# Activity level descriptions
st.info("""
Activity Level Guide:
- **Sedentary**: Little or no exercise, desk job
- **Light**: Light exercise 1-3 times/week
- **Moderate**: Moderate exercise 3-5 times/week
- **Active**: Hard exercise 6-7 times/week
- **Very Active**: Hard daily exercise & physical job
""")

# Medical conditions
st.subheader('🏥 Medical Conditions')
conditions_db = load_medical_conditions()
conditions = st.multiselect('Select any medical conditions:',
    options=conditions_db['condition'].tolist(),
    default=st.session_state.get('conditions', []))

# Display condition details if any selected
if conditions:
    for condition in conditions:
        with st.expander(f"Details for {condition}"):
            condition_data = conditions_db[conditions_db['condition'] == condition].iloc[0]
            col1, col2 = st.columns(2)
            with col1:
                st.write("✅ Recommended Foods:")
                for food in condition_data['recommended_foods'].split('|'):
                    st.write(f"- {food}")
            with col2:
                st.write("❌ Foods to Avoid:")
                for food in condition_data['foods_to_avoid'].split('|'):
                    st.write(f"- {food}")
            
            st.write("💊 Recommended Supplements:")
            for supplement in condition_data['recommended_supplements'].split('|'):
                st.write(f"- {supplement}")

# Calculate BMR and TDEE
bmr = calculate_bmr(weight, height, age, gender)

# Activity level multipliers
activity_multipliers = {
    'Sedentary': 1.2,
    'Light': 1.375,
    'Moderate': 1.55,
    'Active': 1.725,
    'Very Active': 1.9
}

tdee = bmr * activity_multipliers[activity_level]

# Display calculated values
st.subheader('🔥 Energy Requirements')
col1, col2 = st.columns(2)
with col1:
    st.metric("Basal Metabolic Rate (BMR)", f"{bmr:.0f} kcal/day")
with col2:
    st.metric("Total Daily Energy Expenditure (TDEE)", f"{tdee:.0f} kcal/day")

st.info("""
- **BMR**: Calories your body burns at rest
- **TDEE**: Total calories you burn daily with activity
""")

# Save button
if st.button("💾 Save Profile", type="primary"):
    # Save all values to session state
    st.session_state.age = age
    st.session_state.gender = gender
    st.session_state.weight = weight
    st.session_state.height = height
    st.session_state.activity_level = activity_level
    st.session_state.conditions = conditions
    st.session_state.bmr = bmr
    st.session_state.tdee = tdee
    
    st.success("✅ Profile saved successfully! Your personalized settings will be used for meal analysis.")
