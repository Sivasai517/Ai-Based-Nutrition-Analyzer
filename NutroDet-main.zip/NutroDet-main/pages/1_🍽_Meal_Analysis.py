import streamlit as st
from utils import (
    load_food_database, extract_food_items, calculate_nutrition,
    analyze_nutrition, create_nutrition_chart
)

st.title('🍽️ Meal Analysis')
st.write('Enter your meal description and get personalized nutrition analysis!')

# Get user profile from session state
bmr = st.session_state.get('bmr', 2000)
age = st.session_state.get('age', 30)
gender = st.session_state.get('gender', 'Female')
tdee = st.session_state.get('tdee', None)
conditions = st.session_state.get('conditions', [])

# User input
meal_input = st.text_area('Describe your meal:', 
                         placeholder='Example: I had 2 boiled eggs, 1 cup of dal, and 1 apple')

if st.button('Analyze Meal', type='primary'):
    if meal_input:
        # Process the input
        extracted_items = extract_food_items(meal_input)
        nutrition_totals = calculate_nutrition(extracted_items)
        analysis = analyze_nutrition(nutrition_totals, bmr=bmr, age=age, gender=gender, tdee=tdee)
        
        # Display results in columns
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.subheader('📊 Nutrition Analysis')
            # Display nutrition chart
            st.plotly_chart(create_nutrition_chart(nutrition_totals), use_container_width=True)
            
        with col2:
            st.subheader('📋 Food Items')
            for item in extracted_items:
                st.info(f"🍽️ {item['Food']}: {item['Quantity']}")
        
        # Display detailed analysis
        st.subheader('🔍 Detailed Analysis')
        col1, col2, col3 = st.columns([1, 1, 1])
        
        with col1:
            st.write('📊 Nutrition Totals')
            for nutrient, value in nutrition_totals.items():
                st.text(f"{nutrient}: {value:.1f}")
        
        with col2:
            st.write('⚠️ Nutritional Concerns')
            if analysis["Deficient_Nutrients"]:
                st.warning(f'Low in: {", ".join(analysis["Deficient_Nutrients"])}')
            if analysis["Excess_Nutrients"]:
                st.warning(f'High in: {", ".join(analysis["Excess_Nutrients"])}')
            st.info(analysis["Feedback"])
        
        with col3:
            if conditions:
                st.write('👩‍⚕️ Health Recommendations')
                conditions_db = load_medical_conditions()
                for condition in conditions:
                    condition_data = conditions_db[conditions_db['condition'] == condition].iloc[0]
                    recommended = condition_data['recommended_foods'].split('|')
                    avoid = condition_data['foods_to_avoid'].split('|')
                    st.warning(f'For {condition}:')
                    st.success(f'✅ Recommended: {", ".join(recommended[:3])}')
                    st.error(f'❌ Avoid: {", ".join(avoid[:3])}')
            
        # Calorie analysis
        st.subheader('🔥 Energy Balance')
        meal_calories = nutrition_totals['Calories']
        daily_target = tdee if tdee is not None else bmr * 1.2
        meal_target = daily_target / 3  # Assume 3 meals per day
        
        st.metric(
            label="Meal Calories",
            value=f"{meal_calories:.0f} kcal",
            delta=f"{meal_calories - meal_target:.0f} kcal vs. target",
            delta_color="inverse"
        )
        
        # Progress bar for daily calories
        st.progress(min(meal_calories / meal_target, 1.0), 
                   text=f'This meal provides {(meal_calories/daily_target*100):.1f}% of your daily calorie needs ({daily_target:.0f} kcal)')
        
        # Health tips based on conditions and nutrition
        st.subheader('💡 Personalized Tips')
        tips = [
            "Try to eat a variety of colorful foods to ensure you get all essential nutrients!",
            f"Your daily calorie target is {daily_target:.0f} kcal based on your profile.",
            "Space your meals evenly throughout the day for better energy levels."
        ]
        
        for tip in tips:
            st.success(tip)
