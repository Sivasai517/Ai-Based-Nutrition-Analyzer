import streamlit as st
from utils import load_medical_conditions

st.title('🏥 Health Conditions')
st.write('Learn about different health conditions and their dietary recommendations.')

# Load medical conditions database
conditions_db = load_medical_conditions()

# Search functionality
search = st.text_input('🔍 Search health conditions:', placeholder='Enter condition name...')

if search:
    filtered_conditions = conditions_db[conditions_db['condition'].str.lower().str.contains(search.lower())]
else:
    filtered_conditions = conditions_db

# Display conditions
for _, condition in filtered_conditions.iterrows():
    with st.expander(f"🔍 {condition['condition']}"):
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader('✅ Recommended Foods')
            for food in condition['recommended_foods'].split('|'):
                st.write(f"- {food}")
                
            st.subheader('💊 Recommended Supplements')
            for supplement in condition['recommended_supplements'].split('|'):
                st.write(f"- {supplement}")
        
        with col2:
            st.subheader('❌ Foods to Avoid')
            for food in condition['foods_to_avoid'].split('|'):
                st.write(f"- {food}")
                
            st.subheader('💉 Common Medications')
            for medication in condition['medications'].split('|'):
                st.write(f"- {medication}")

# Download database
st.subheader('📥 Download Database')
@st.cache_data
def convert_df_to_csv(df):
    return df.to_csv(index=False).encode('utf-8')

csv = convert_df_to_csv(conditions_db)
st.download_button(
    "Download Health Conditions Database as CSV",
    csv,
    "medical_conditions.csv",
    "text/csv",
    key='download-csv'
)
