import streamlit as st
import pandas as pd
from utils import load_food_database

st.title('📊 Food Database')
st.write('Explore our comprehensive food database with detailed nutritional information.')

# Load the food database
db = load_food_database()

# Search functionality
search = st.text_input('🔍 Search for foods:', placeholder='Enter food name...')

if search:
    filtered_db = db[db['food_name'].str.lower().str.contains(search.lower())]
else:
    filtered_db = db

# Sorting options
sort_col = st.selectbox('Sort by:', ['food_name'] + list(db.columns[1:]))
sort_order = st.radio('Sort order:', ['Ascending', 'Descending'], horizontal=True)

# Apply sorting
filtered_db = filtered_db.sort_values(sort_col, ascending=(sort_order == 'Ascending'))

# Display database
st.dataframe(
    filtered_db,
    column_config={
        "food_name": "Food Name",
        "serving_size": "Serving Size",
        "calories": st.column_config.NumberColumn("Calories", format="%.1f kcal"),
        "protein": st.column_config.NumberColumn("Protein", format="%.1f g"),
        "carbohydrates": st.column_config.NumberColumn("Carbs", format="%.1f g"),
        "fats": st.column_config.NumberColumn("Fats", format="%.1f g"),
        "fiber": st.column_config.NumberColumn("Fiber", format="%.1f g"),
    },
    hide_index=True,
    use_container_width=True
)

# Nutritional content visualization
if st.checkbox('Show Nutritional Content Visualization'):
    st.subheader('Nutritional Content Comparison')
    
    # Select foods to compare
    foods_to_compare = st.multiselect(
        'Select foods to compare:',
        db['food_name'].tolist(),
        max_selections=5
    )
    
    if foods_to_compare:
        # Select nutrients to compare
        nutrients = st.multiselect(
            'Select nutrients to compare:',
            ['calories', 'protein', 'carbohydrates', 'fats', 'fiber'],
            default=['calories', 'protein', 'carbohydrates', 'fats']
        )
        
        if nutrients:
            # Create comparison dataframe
            comparison_df = db[db['food_name'].isin(foods_to_compare)][['food_name'] + nutrients]
            comparison_df = comparison_df.set_index('food_name')
            
            # Create bar chart
            st.bar_chart(comparison_df)
            
            # Show detailed comparison table
            st.write('Detailed Comparison:')
            st.dataframe(comparison_df, use_container_width=True)

# Download database
st.subheader('📥 Download Database')
@st.cache_data
def convert_df_to_csv(df):
    return df.to_csv(index=False).encode('utf-8')

csv = convert_df_to_csv(db)
st.download_button(
    "Download Food Database as CSV",
    csv,
    "food_database.csv",
    "text/csv",
    key='download-csv'
)
